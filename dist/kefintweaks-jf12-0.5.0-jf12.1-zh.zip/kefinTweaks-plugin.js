// KefinTweaks Installer
// Entry point script for KefinTweaks installation and configuration
// Users paste this script into JS Injector instead of injector.js

(function() {
    'use strict';

    // jf12 fork: two ways in. (1) Upstream's: this file IS the JavaScript Injector entry and adds a KefinTweaks card to the Plugins page. (2) The fork's hand-written entries (KefinTweaks-Config +
    // KefinTweaks-injector): injector.js is already running and this file is only loaded on demand, by the "Plugin Settings" button of the configuration page, for the dialog it defines. Then
    // it adds no card, and saving a new location must not start a second injector.js next to the running one (the page is reloaded instead).
    const BOOTSTRAPPED = !!window.KefinTweaksBootstrapRoot;

    console.log('[KefinTweaks Installer] Initializing...' + (BOOTSTRAPPED ? ' (dialog only: KefinTweaks is already running)' : ''));

    const MODAL_ID = 'kefinTweaksSourceModal';
    let versionsCache = null;

    function getAuthHeader() {
        const token = ApiClient.accessToken();
        const client = typeof ApiClient.applicationName === 'function' ? ApiClient.applicationName() : 'Jellyfin Web';
        const device = typeof ApiClient.deviceName === 'function' ? ApiClient.deviceName() : (navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Browser');
        const deviceId = typeof ApiClient.deviceId === 'function' ? ApiClient.deviceId() : '';
        const version = ApiClient._appVersion || ApiClient._serverVersion || '';
        const parts = [
            `Client="${encodeURIComponent(client)}"`,
            `Device="${encodeURIComponent(device)}"`,
            `DeviceId="${encodeURIComponent(deviceId)}"`,
            `Version="${encodeURIComponent(version)}"`,
            `Token="${encodeURIComponent(token)}"`
        ];
        return `MediaBrowser ${parts.join(', ')}`;
    }

    // jf12 fork: no GitHub release list and no jsDelivr branch URLs. KefinTweaks loads from the root set in the
    // KefinTweaks-Config entry (a commit-pinned URL or a self-hosted folder); see docs/JF12-FORK.md. This installer card is
    // optional in the fork (the two JavaScript Injector entries can be written by hand) and it never writes on page load.

    // Check if user is admin
    async function isAdmin() {
        try {
            if (window.ApiClient && window.ApiClient.getCurrentUser) {
                const user = await window.ApiClient.getCurrentUser();
                return user && user.Policy && user.Policy.IsAdministrator === true;
            }
        } catch (error) {
            console.warn('[KefinTweaks Installer] Could not check admin status:', error);
        }
        return false;
    }

    // Find JavaScript Injector plugin
    async function findJavaScriptInjectorPlugin() {
        try {
            if (!window.ApiClient || !window.ApiClient._serverAddress || window.ApiClient.accessToken() === null) {
                return null;
            }

            const server = ApiClient._serverAddress;

            const response = await fetch(`${server}/Plugins`, {
                headers: {
                    'Authorization': getAuthHeader()
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const plugins = await response.json();
            const pluginsList = Array.isArray(plugins) ? plugins : (plugins.Items || []);
            
            const injectorPlugin = pluginsList.find(plugin => 
                plugin.Name === 'JavaScript Injector' || plugin.Name === 'JS Injector'
            );

            if (!injectorPlugin) {
                throw new Error('未找到 JavaScript Injector 插件');
            }

            return injectorPlugin.Id;
        } catch (error) {
            console.error('[KefinTweaks Installer] Error finding JavaScript Injector plugin:', error);
            throw error;
        }
    }

    // Get current JavaScript Injector configuration
    async function getJavaScriptInjectorConfig(pluginId) {
        try {
            if (!window.ApiClient || !window.ApiClient._serverAddress || !window.ApiClient.accessToken) {
                return null;
            }

            const server = ApiClient._serverAddress;

            const response = await fetch(`${server}/Plugins/${pluginId}/Configuration`, {
                headers: {
                    'Authorization': getAuthHeader()
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('[KefinTweaks Installer] Error getting JS Injector config:', error);
            throw error;
        }
    }

    // Get KefinTweaks config from JS Injector
    async function getKefinTweaksConfig() {
        try {            
            if (window.KefinTweaksConfig) {
                return window.KefinTweaksConfig;
            }

            const pluginId = await findJavaScriptInjectorPlugin();

            if (!pluginId) {
                return null;
            }

            const injectorConfig = await getJavaScriptInjectorConfig(pluginId);

            if (!injectorConfig) {
                return null;
            }
            
            const kefinTweaksScript = injectorConfig.CustomJavaScripts?.find(
                script => script.Name === 'KefinTweaks-Config'
            );
            
            if (kefinTweaksScript && kefinTweaksScript.Script) {
                const scriptMatch = kefinTweaksScript.Script.match(/window\.KefinTweaksConfig\s*=\s*({[\s\S]*});/);
                if (scriptMatch && scriptMatch[1]) {
                    try {
                        return JSON.parse(scriptMatch[1]);
                    } catch (parseError) {
                        console.error('[KefinTweaks Installer] Error parsing config:', parseError);
                    }
                }
            }
        } catch (error) {
            console.warn('[KefinTweaks Installer] Error getting config:', error);
        }
        return null;
    }

    // Load default config from URL (resolves floating refs first, same as injector load)
    async function loadDefaultConfig(rootUrl) {
        const normalizedRoot = rootUrl.endsWith('/') ? rootUrl : rootUrl + '/';
        const resolvedRoot = await resolveRootVersion(normalizedRoot);
        if (resolvedRoot !== normalizedRoot) {
            console.log('[KefinTweaks Installer] Resolved default-config root from', normalizedRoot, 'to', resolvedRoot);
        }

        return new Promise((resolve, reject) => {
            try {
                const defaultConfigUrl = `${resolvedRoot}kefinTweaks-default-config.js`;

                if (window.KefinTweaksDefaultConfig) {
                    resolve(window.KefinTweaksDefaultConfig);
                    return;
                }

                const script = document.createElement('script');
                script.src = defaultConfigUrl;
                script.async = true;

                script.onload = () => {
                    if (window.KefinTweaksDefaultConfig) {
                        resolve(window.KefinTweaksDefaultConfig);
                    } else {
                        reject(new Error('Default config file loaded but window.KefinTweaksDefaultConfig is not defined'));
                    }
                };

                script.onerror = () => {
                    reject(new Error(`Failed to load default config file: ${defaultConfigUrl}`));
                };

                document.head.appendChild(script);
            } catch (error) {
                reject(error);
            }
        });
    }

    // Save configuration to JavaScript Injector (Config + KefinTweaks-injector preload)
    async function saveConfigToJavaScriptInjector(config) {
        try {
            const pluginId = await findJavaScriptInjectorPlugin();
            const injectorConfig = await getJavaScriptInjectorConfig(pluginId);
                
            if (!injectorConfig.CustomJavaScripts) {
                injectorConfig.CustomJavaScripts = [];
            }

            const scriptContent = `// KefinTweaks Configuration
// This file is automatically generated by KefinTweaks Installer
// Do not edit manually unless you know what you're doing

window.KefinTweaksConfig = ${JSON.stringify(config, null, 2)};`;

            let injectorScriptContent = null;
            try {
                const rootRaw = config.kefinTweaksRoot || '';
                const resolvedRaw = config.kefinTweaksRootResolved || rootRaw;
                const root = resolvedRaw.endsWith('/') ? resolvedRaw : resolvedRaw + '/';
                if (root && root !== '/') {
                    await loadKefinTweaksLoaderFromRoot(root);
                    const Loader = window.KefinTweaksLoader;
                    if (Loader) {
                        Loader.ensureKefinTweaksApi(Loader.SCRIPT_DEFINITIONS);
                        let major = null;
                        try {
                            major = await window.KefinTweaks.getJellyfinMajorVersion();
                        } catch (e) {
                            console.warn('[KefinTweaks Installer] Could not resolve Jellyfin major for injector bake:', e);
                        }
                        const planRoot = Loader.getResolvedKefinRoot
                            ? Loader.getResolvedKefinRoot(config)
                            : root;
                        const plan = Loader.buildLoadPlan(config, major, {
                            root: planRoot,
                            configOnly: config.enabled === false
                        });
                        injectorScriptContent = Loader.buildInjectorScript(plan);
                        console.log('[KefinTweaks Installer] Built KefinTweaks-injector with', plan.assets.length, 'assets');
                    }
                }
            } catch (e) {
                console.warn('[KefinTweaks Installer] Failed to build KefinTweaks-injector:', e);
            }

            if (window.KefinTweaksLoader) {
                injectorConfig.CustomJavaScripts = window.KefinTweaksLoader.upsertInjectorEntries(
                    injectorConfig.CustomJavaScripts,
                    { configScriptContent: scriptContent, injectorScriptContent }
                );
            } else {
                const existingScriptIndex = injectorConfig.CustomJavaScripts.findIndex(
                    script => script.Name === 'KefinTweaks-Config'
                );
                if (existingScriptIndex !== -1) {
                    injectorConfig.CustomJavaScripts[existingScriptIndex].Script = scriptContent;
                    injectorConfig.CustomJavaScripts[existingScriptIndex].Enabled = true;
                } else {
                    injectorConfig.CustomJavaScripts.push({
                        Name: 'KefinTweaks-Config',
                        Script: scriptContent,
                        Enabled: true,
                        RequiresAuthentication: false
                    });
                }
            }

            const server = ApiClient._serverAddress;

            const response = await fetch(`${server}/Plugins/${pluginId}/Configuration`, {
                method: 'POST',
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(injectorConfig)
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            return true;
        } catch (error) {
            console.error('[KefinTweaks Installer] Error saving config:', error);
            throw error;
        }
    }

    function loadKefinTweaksLoaderFromRoot(root) {
        const normalized = root.endsWith('/') ? root : root + '/';
        const url = `${normalized}scripts/kefinTweaks-loader.js`;
        if (window.KefinTweaksLoader) return Promise.resolve(window.KefinTweaksLoader);
        return new Promise((resolve, reject) => {
            const existing = document.querySelector(`script[src="${url}"]`);
            if (existing) {
                const start = Date.now();
                const wait = () => {
                    if (window.KefinTweaksLoader) return resolve(window.KefinTweaksLoader);
                    if (Date.now() - start > 15000) return reject(new Error('等待 KefinTweaksLoader 超时'));
                    setTimeout(wait, 50);
                };
                return wait();
            }
            const script = document.createElement('script');
            script.src = url;
            script.async = false;
            script.onload = () => resolve(window.KefinTweaksLoader);
            script.onerror = () => reject(new Error('加载失败：' + url));
            document.head.appendChild(script);
        });
    }

    function isLoggedInForInjectorWrite() {
        try {
            return !!(window.ApiClient
                && window.ApiClient._loggedIn
                && typeof window.ApiClient.accessToken === 'function'
                && window.ApiClient.accessToken()
                && window.ApiClient._serverAddress);
        } catch (e) {
            return false;
        }
    }

    async function waitForLoginForInjectorWrite(maxWaitMs = 10000, checkInterval = 250) {
        if (isLoggedInForInjectorWrite()) return true;
        const start = Date.now();
        while (Date.now() - start < maxWaitMs) {
            await new Promise((r) => setTimeout(r, checkInterval));
            if (isLoggedInForInjectorWrite()) return true;
        }
        return false;
    }

    /**
     * Create/update KefinTweaks-injector (and Config) in JS Injector when missing.
     * @returns {Promise<{ ok: boolean, plan?: object, reason?: string }>}
     */
    async function ensureKefinTweaksInjectorEntry(config) {
        const rootRaw = config?.kefinTweaksRoot || '';
        if (!rootRaw) {
            return { ok: false, reason: 'kefinTweaksRoot not configured' };
        }

        if (!isLoggedInForInjectorWrite()) {
            return { ok: false, reason: 'not logged in' };
        }

        try {
            const normalize = (r) => {
                if (!r || typeof r !== 'string') return '';
                return r.endsWith('/') ? r : r + '/';
            };

            const expected = normalize(await resolveRootVersion(rootRaw));
            const current = normalize(config.kefinTweaksRootResolved || '');
            if (!current || current !== expected) {
                config.kefinTweaksRootResolved = expected;
                console.log('[KefinTweaks Installer] Updated kefinTweaksRootResolved:', current || '(none)', '->', expected);
            }

            const loadRoot = normalize(config.kefinTweaksRootResolved || rootRaw);
            await loadKefinTweaksLoaderFromRoot(loadRoot);
            const Loader = window.KefinTweaksLoader;
            if (!Loader) {
                return { ok: false, reason: 'KefinTweaksLoader unavailable' };
            }

            Loader.ensureKefinTweaksApi(Loader.SCRIPT_DEFINITIONS);
            let major = null;
            try {
                major = await window.KefinTweaks.getJellyfinMajorVersion();
            } catch (e) {
                console.warn('[KefinTweaks Installer] Could not resolve Jellyfin major for auto-create:', e);
            }

            const resolvedRoot = Loader.getResolvedKefinRoot(config);
            const plan = Loader.buildLoadPlan(config, major, {
                root: resolvedRoot,
                configOnly: config.enabled === false
            });
            const injectorScriptContent = Loader.buildInjectorScript(plan);
            const configScriptContent = `// KefinTweaks Configuration
// This file is automatically generated by KefinTweaks Installer
// Do not edit manually unless you know what you're doing

window.KefinTweaksConfig = ${JSON.stringify(config, null, 2)};`;

            const pluginId = await findJavaScriptInjectorPlugin();
            if (!pluginId) {
                return { ok: false, reason: 'JavaScript Injector plugin not found' };
            }
            const injectorConfig = await getJavaScriptInjectorConfig(pluginId);
            if (!injectorConfig) {
                return { ok: false, reason: 'Could not read JS Injector configuration' };
            }
            if (!injectorConfig.CustomJavaScripts) {
                injectorConfig.CustomJavaScripts = [];
            }

            injectorConfig.CustomJavaScripts = Loader.upsertInjectorEntries(
                injectorConfig.CustomJavaScripts,
                { configScriptContent, injectorScriptContent }
            );

            const server = ApiClient._serverAddress;
            const response = await fetch(`${server}/Plugins/${pluginId}/Configuration`, {
                method: 'POST',
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(injectorConfig)
            });

            if (!response.ok) {
                return {
                    ok: false,
                    reason: `POST failed HTTP ${response.status}: ${response.statusText}`
                };
            }

            console.log('[KefinTweaks Installer] Auto-created KefinTweaks-injector with', plan.assets.length, 'assets');
            return { ok: true, plan };
        } catch (err) {
            console.warn('[KefinTweaks Installer] ensureKefinTweaksInjectorEntry failed:', err);
            return { ok: false, reason: err?.message || String(err) };
        }
    }

    function hasEnabledKefinInjectorEntry(customJavaScripts) {
        if (window.KefinTweaksLoader?.hasEnabledInjectorEntry) {
            return window.KefinTweaksLoader.hasEnabledInjectorEntry(customJavaScripts);
        }
        return (customJavaScripts || []).some(
            (s) => s.Name === 'KefinTweaks-injector' && s.Enabled !== false
        );
    }

    const LATEST_RELEASE_NAME = 'Latest';
    const DEVELOPMENT_NAME = 'Development';
    const EXPERIMENTAL_NAME = 'Experimental';
    const SELF_HOSTED_NAME = 'Self Hosted';

    // Parse source URL to determine source type and version (jf12 fork: every root is a custom, pinned root)
    function parseKefinTweaksSource(url) {
        return { sourceType: 'custom', version: null };
    }

    // jf12 fork: no version list from GitHub; the only source is a custom (self-hosted or commit-pinned) root
    async function fetchVersions() {
        return [];
    }

    // Build kefinTweaksRoot URL from selections (jf12 fork: the custom URL, with a trailing slash)
    function buildKefinTweaksRootUrl(sourceType, source) {
        const root = String(source || '').trim();
        return root.endsWith('/') ? root : root + '/';
    }

    // Simple modal creation (doesn't depend on modal.js)
    function createSimpleModal(id, title, content, footer) {
        // Remove existing modal
        const existing = document.getElementById(id);
        if (existing) {
            existing.remove();
        }

        const backdrop = document.createElement('div');
        backdrop.className = 'dialogBackdrop dialogBackdropOpened';
        backdrop.id = id + '-backdrop';

        const dialogContainer = document.createElement('div');
        dialogContainer.className = 'dialogContainer';
        dialogContainer.id = id;

        const dialog = document.createElement('div');
        dialog.className = 'focuscontainer dialog smoothScrollY ui-body-a background-theme-a formDialog centeredDialog opened';
        dialog.style.display = 'flex';
        dialog.style.flexDirection = 'column';

        if (window.innerWidth < 900) {
            dialog.style.maxHeight = '90vh';
            dialog.style.maxWidth = '600px';
            dialog.style.width = '90vw';
        }

        if (title) {
            const header = document.createElement('div');
            header.className = 'formDialogHeader';
            header.style.display = 'flex';
            header.style.justifyContent = 'space-between';
            header.style.alignItems = 'center';
            header.style.padding = '1.25em 1.5em';
            header.style.borderBottom = '1px solid rgba(255,255,255,0.1)';

            const titleEl = document.createElement('h2');
            titleEl.style.margin = '0';
            titleEl.textContent = title;
            header.appendChild(titleEl);

            const closeBtn = document.createElement('button');
            closeBtn.setAttribute('is', 'paper-icon-button-light');
            closeBtn.className = 'btnCancel btnClose autoSize paper-icon-button-light';
            closeBtn.onclick = () => closeSimpleModal(id);
            const closeIcon = document.createElement('span');
            closeIcon.className = 'material-icons close';
            closeBtn.appendChild(closeIcon);
            header.appendChild(closeBtn);

            dialog.appendChild(header);
        }

        const contentDiv = document.createElement('div');
        contentDiv.style.padding = '1.25em 1.5em 8em';
        contentDiv.style.overflowY = 'auto';
        contentDiv.style.flex = '1';
        if (typeof content === 'string') {
            contentDiv.innerHTML = content;
        } else {
            contentDiv.appendChild(content);
        }
        dialog.appendChild(contentDiv);

        if (footer) {
            const footerDiv = document.createElement('div');
            footerDiv.className = 'formDialogFooter';
            footerDiv.style.padding = '1.25em 1.5em';
            footerDiv.style.borderTop = '1px solid rgba(255,255,255,0.1)';
            if (typeof footer === 'string') {
                footerDiv.innerHTML = footer;
            } else {
                footerDiv.appendChild(footer);
            }
            dialog.appendChild(footerDiv);
        }

        dialogContainer.appendChild(dialog);
        document.body.appendChild(backdrop);
        document.body.appendChild(dialogContainer);

        backdrop.onclick = (e) => {
            if (e.target === backdrop) {
                closeSimpleModal(id);
            }
        };

        // Close modal when clicking outside (on dialogContainer)
        dialogContainer.onclick = (e) => {
            if (e.target === dialogContainer) {
                closeSimpleModal(id);
            }
        };

        return { id, close: () => closeSimpleModal(id) };
    }

    function closeSimpleModal(id) {
        const backdrop = document.getElementById(id + '-backdrop');
        const dialog = document.getElementById(id);
        if (backdrop) backdrop.remove();
        if (dialog) dialog.remove();
    }

    /**
     * Show a confirmation modal
     * @param {string} message - Confirmation message
     * @param {Function} onConfirm - Callback when user confirms
     * @param {Function} onCancel - Optional callback when user cancels
     */
    function showConfirmationModal(message, onConfirm, onCancel = null) {
        const CONFIRM_MODAL_ID = 'kefinTweaksConfirmModal';
        
        const content = document.createElement('div');
        content.style.display = 'flex';
        content.style.flexDirection = 'column';
        content.style.gap = '1em';
        content.style.lineHeight = '1.6';
        content.innerHTML = `<p>${message}</p>`;

        const footer = document.createElement('div');
        footer.style.display = 'flex';
        footer.style.justifyContent = 'flex-end';
        footer.style.gap = '1em';

        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'btnCancel raised emby-button button-cancel';
        cancelBtn.textContent = '取消';
        cancelBtn.onclick = () => {
            closeSimpleModal(CONFIRM_MODAL_ID);
            if (onCancel) onCancel();
        };

        const confirmBtn = document.createElement('button');
        confirmBtn.className = 'btnSubmit raised emby-button button-submit';
        confirmBtn.textContent = '确认';
        confirmBtn.onclick = () => {
            closeSimpleModal(CONFIRM_MODAL_ID);
            if (onConfirm) onConfirm();
        };

        footer.appendChild(cancelBtn);
        footer.appendChild(confirmBtn);

        createSimpleModal(CONFIRM_MODAL_ID, '确认', content, footer);
    }

    /**
     * Show an alert/info modal
     * @param {string} title - Modal title
     * @param {string} message - Message content (can include HTML)
     */
    function showAlertModal(title, message) {
        const ALERT_MODAL_ID = 'kefinTweaksAlertModal';
        
        const content = document.createElement('div');
        content.style.display = 'flex';
        content.style.flexDirection = 'column';
        content.style.gap = '1em';
        content.style.lineHeight = '1.6';
        content.innerHTML = message;

        const footer = document.createElement('div');
        footer.style.display = 'flex';
        footer.style.justifyContent = 'flex-end';
        footer.style.gap = '1em';

        const okBtn = document.createElement('button');
        okBtn.className = 'btnSubmit raised emby-button button-submit';
        okBtn.textContent = '确定';
        okBtn.onclick = () => {
            closeSimpleModal(ALERT_MODAL_ID);
        };

        footer.appendChild(okBtn);

        createSimpleModal(ALERT_MODAL_ID, title, content, footer);
    }

    /**
     * Show success modal after saving configuration
     * @param {boolean} isInitialInstall - Whether this is the initial installation
     * @param {string} version - Version number or source type
     */
    async function showSuccessModal(isInitialInstall, version) {
        const SUCCESS_MODAL_ID = 'kefinTweaksSuccessModal';
        
        const content = document.createElement('div');
        content.style.display = 'flex';
        content.style.flexDirection = 'column';
        content.style.lineHeight = '1.6';

        if (isInitialInstall) {
            // Initial installation message with support information
            content.innerHTML = `
                <p>非常感谢您安装 KefinTweaks！</p>
                <p>KefinTweaks 并非由 Jellyfin 团队维护，因此建议您直接向我寻求支持。</p>
                <p>遗憾的是，官方 Jellyfin Discord 中<i>目前</i>还没有适合讨论社区成员制作的插件或粉丝项目的版块，请前往 <a href="https://discord.gg/v7P9CAvCKZ" target="_blank" style="color: #00a4dc; text-decoration: underline;">Jellyfin Community Discord</a> 找我（用户名：HighImKevin）以及其他乐意为您提供帮助的用户。</p>
                <p>也欢迎随时在 <a href="${(window.KefinTweaksLoader?.UPSTREAM?.repository || '')}/issues" target="_blank" style="color: #00a4dc; text-decoration: underline;">Issues</a> 页面报告错误和提出功能建议。这个插件的强大离不开像您这样出色的社区成员，感谢您使用 KefinTweaks！</p>
            `;
        } else {
            // Update message with refresh instruction
            content.innerHTML = `
                <p>KefinTweaks 配置已成功更新。请刷新页面以使更改生效！</p>
            `;
        }

        // Add discord icon link to the bottom of the content use a background img on an element
        const kefinRoot = window.KefinTweaksConfig?.kefinTweaksRoot;

        if (kefinRoot) {
            // Wrapped in a link to the discord server
            const discordLinkWrapper = document.createElement('div');
            discordLinkWrapper.style.display = 'flex';
            discordLinkWrapper.style.justifyContent = 'center';

            const discordLink = document.createElement('a');
            discordLink.href = 'https://discord.gg/v7P9CAvCKZ';
            discordLink.target = '_blank';
            discordLink.style.display = 'inline-block';
            discordLink.style.width = '50px';


            const discordIcon = document.createElement('div');
            discordIcon.style.backgroundImage = `url(${kefinRoot}/pages/images/discord.png)`;
            discordIcon.style.backgroundSize = 'contain';
            discordIcon.style.backgroundPosition = 'center';
            discordIcon.style.backgroundRepeat = 'no-repeat';
            discordIcon.style.height = '35px';
            discordLink.appendChild(discordIcon);
            discordLinkWrapper.appendChild(discordLink);
            content.appendChild(discordLinkWrapper);
        }

        const footer = document.createElement('div');
        footer.style.display = 'flex';
        footer.style.justifyContent = 'flex-end';
        footer.style.gap = '1em';

        const okBtn = document.createElement('button');
        okBtn.className = 'btnSubmit raised emby-button button-submit';
        okBtn.textContent = '确定';
        okBtn.onclick = () => {
            closeSimpleModal(SUCCESS_MODAL_ID);
            if (!isInitialInstall) {
                // Optionally auto-refresh on update (or let user do it manually)
                // window.location.reload();
            }
        };

        footer.appendChild(okBtn);

        // Close original KefinTweaksConfiguration Modal if it is open
        const kefinTweaksConfigurationModals = document.querySelectorAll('[data-modal-id="kefinTweaksConfigModal"]');
        if (kefinTweaksConfigurationModals.length > 0) {
            kefinTweaksConfigurationModals.forEach(modal => {
                modal.remove();
            });
        }

        createSimpleModal(SUCCESS_MODAL_ID, `${isInitialInstall ? '插件已安装' : '插件已更新'}`, content, footer);

        
    }

    // Open source configuration modal
    async function openKefinTweaksSourceModal() {
        const userIsAdmin = await isAdmin();
        if (!userIsAdmin) {
            showAlertModal('访问被拒绝', '<p>您必须是管理员才能配置 KefinTweaks。</p>');
            return;
        }

        const currentConfig = await getKefinTweaksConfig();
        const currentRoot = currentConfig?.kefinTweaksRoot || '';
        const sourceInfo = parseKefinTweaksSource(currentRoot);
        const versions = await fetchVersions();

        const content = document.createElement('div');
        content.style.display = 'flex';
        content.style.flexDirection = 'column';
        content.style.gap = '1.5em';

        // Enabled checkbox
        const isEnabled = currentConfig?.enabled !== false;
        const enabledContainer = document.createElement('div');
        enabledContainer.style.display = 'flex';
        enabledContainer.style.alignItems = 'center';
        enabledContainer.style.gap = '0.75em';
        
        const enabledCheckbox = document.createElement('input');
        enabledCheckbox.type = 'checkbox';
        enabledCheckbox.id = 'kefinTweaksEnabledModal';
        enabledCheckbox.className = 'checkbox';
        enabledCheckbox.checked = isEnabled;
        
        const enabledLabel = document.createElement('label');
        enabledLabel.setAttribute('for', 'kefinTweaksEnabledModal');
        enabledLabel.style.cursor = 'pointer';
        enabledLabel.style.margin = '0';
        enabledLabel.style.display = 'flex';
        enabledLabel.style.alignItems = 'center';
        enabledLabel.style.gap = '0.75em';
        
        const enabledText = document.createElement('span');
        enabledText.textContent = isEnabled ? '已启用' : '已禁用';
        enabledText.id = 'kefinTweaksEnabledModalLabel';
        
        enabledLabel.appendChild(enabledCheckbox);
        enabledLabel.appendChild(enabledText);
        enabledContainer.appendChild(enabledLabel);
        
        // Update label text when checkbox changes
        enabledCheckbox.addEventListener('change', () => {
            enabledText.textContent = enabledCheckbox.checked ? '已启用' : '已禁用';
        });
        
        content.appendChild(enabledContainer);

        // Source Type dropdown
        const sourceTypeLabel = document.createElement('label');
        sourceTypeLabel.textContent = '安装来源：';
        sourceTypeLabel.style.display = 'block';
        sourceTypeLabel.style.marginBottom = '0.5em';

        const sourceTypeSelect = document.createElement('select');
        sourceTypeSelect.className = 'fld emby-select emby-select-withcolor';
        sourceTypeSelect.id = 'kefinTweaksSourceType';
        sourceTypeSelect.innerHTML = `
            <option value="custom" selected>${SELF_HOSTED_NAME}（固定 URL）</option>
        `;

        // Source dropdown (for GitHub)
        const sourceLabel = document.createElement('label');
        sourceLabel.textContent = '版本：';
        sourceLabel.style.display = 'block';
        sourceLabel.style.marginBottom = '0.5em';

        const sourceSelect = document.createElement('select');
        sourceSelect.className = 'fld emby-select emby-select-withcolor';
        sourceSelect.id = 'kefinTweaksSource';
        sourceSelect.innerHTML = versions.map(v => 
            `<option value="${v}" ${v === sourceInfo.version ? 'selected' : ''}>${v}</option>`
        ).join('');

        // Custom URL input
        const customUrlInput = document.createElement('input');
        customUrlInput.type = 'text';
        customUrlInput.className = 'fld emby-input';
        customUrlInput.id = 'kefinTweaksCustomUrl';
        customUrlInput.placeholder = 'https://example.com/KefinTweaks/';
        customUrlInput.value = sourceInfo.sourceType === 'custom' ? currentRoot : '';
        customUrlInput.style.display = sourceInfo.sourceType === 'custom' ? 'block' : 'none';

        // Set initial visibility based on source type
        if (sourceInfo.sourceType === 'custom') {
            sourceSelect.style.display = 'none';
            sourceLabel.style.display = 'none';
            customUrlInput.style.display = 'block';
        } else {
            sourceSelect.style.display = 'block';
            sourceLabel.style.display = 'block';
            customUrlInput.style.display = 'none';
        }

        // Toggle visibility based on source type
        sourceTypeSelect.onchange = () => {
            if (sourceTypeSelect.value === 'custom') {
                sourceSelect.style.display = 'none';
                sourceLabel.style.display = 'none';
                customUrlInput.style.display = 'block';
            } else {
                sourceSelect.style.display = 'block';
                sourceLabel.style.display = 'block';
                customUrlInput.style.display = 'none';
            }
        };

        content.appendChild(sourceTypeLabel);
        content.appendChild(sourceTypeSelect);
        content.appendChild(sourceLabel);
        content.appendChild(sourceSelect);
        content.appendChild(customUrlInput);

        // Footer with buttons
        const footer = document.createElement('div');
        footer.style.display = 'flex';
        footer.style.justifyContent = 'flex-end';
        footer.style.gap = '1em';

        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'btnCancel raised emby-button button-cancel';
        cancelBtn.textContent = '取消';
        cancelBtn.onclick = () => closeSimpleModal(MODAL_ID);

        const saveBtn = document.createElement('button');
        saveBtn.className = 'btnSubmit raised emby-button button-submit';
        saveBtn.textContent = (!currentRoot || currentRoot.trim() === '') ? '安装' : '保存';
        saveBtn.onclick = async () => {
            try {
                const sourceType = sourceTypeSelect.value;
                const source = sourceType === 'custom' ? customUrlInput.value : sourceSelect.value;
                
                if (sourceType === 'custom' && (!source || source.trim() === '')) {
                    showAlertModal('无效 URL', '<p>请为您的自托管位置输入有效的 URL。</p>');
                    return;
                }

                const kefinTweaksRoot = buildKefinTweaksRootUrl(sourceType, source);
                // jf12 fork: a location that does not serve KefinTweaks would take KefinTweaks away, and with it this dialog, on the next page load (the files are loaded from there). Look first.
                try {
                    await probeKefinRoot(kefinTweaksRoot);
                } catch (probeError) {
                    showAlertModal('未保存', `<p>${probeError.message}</p><p>未做任何更改。</p>`);
                    return;
                }
                const kefinTweaksRootResolvedRaw = await resolveRootVersion(kefinTweaksRoot);
                const kefinTweaksRootResolved = kefinTweaksRootResolvedRaw.endsWith('/')
                    ? kefinTweaksRootResolvedRaw
                    : kefinTweaksRootResolvedRaw + '/';
                
                // Load default config from the selected root
                let defaultConfig;
                try {
                    defaultConfig = await loadDefaultConfig(kefinTweaksRoot);
                } catch (error) {
                    console.error('[KefinTweaks Installer] Error loading default config:', error);
                    // Create minimal config if loading fails
                    defaultConfig = {
                        kefinTweaksRoot: kefinTweaksRoot,
                        kefinTweaksRootResolved: kefinTweaksRootResolved,
                        enabled: true,
                        scripts: {},
                        exclusiveElsewhere: {},
                        search: {},
                        skins: [],
                        defaultSkin: null,
                        themes: [],
                        customMenuLinks: [],
                        optionalIncludes: []
                    };
                }

                // Get enabled state from checkbox
                const enabledState = enabledCheckbox.checked;
                
                // Merge with existing config to preserve user settings
                const mergedConfig = {
                    ...defaultConfig,
                    kefinTweaksRoot: kefinTweaksRoot,
                    ...(currentConfig || {}),
                    kefinTweaksRoot: kefinTweaksRoot, // Ensure root is updated
                    kefinTweaksRootResolved: kefinTweaksRootResolved,
                    enabled: enabledState // Update enabled state
                };

                // Remove scriptRoot if it exists (legacy field)
                if (mergedConfig.scriptRoot) {
                    delete mergedConfig.scriptRoot;
                }

                await saveConfigToJavaScriptInjector(mergedConfig);
                
                // Update window.KefinTweaksConfig immediately so injector can use it
                window.KefinTweaksConfig = mergedConfig;
                window.KefinTweaksConfigEnabled = enabledState;
                
                closeSimpleModal(MODAL_ID);
                
                // Update the plugin card with new version/status
                await updateKefinTweaksPluginCard();
                
                // Determine if this is initial installation
                const isInitialInstall = !currentConfig || !currentConfig.kefinTweaksRoot || currentConfig.kefinTweaksRoot === '';
                
                // Get version for display
                const sourceInfo = parseKefinTweaksSource(kefinTweaksRoot);
                let versionDisplay = '';
                if (sourceInfo.sourceType === 'custom') {
                    versionDisplay = SELF_HOSTED_NAME;
                } else if (sourceInfo.version === DEVELOPMENT_NAME) {
                    versionDisplay = DEVELOPMENT_NAME;
                } else if (sourceInfo.version === LATEST_RELEASE_NAME) {
                    versionDisplay = LATEST_RELEASE_NAME; // jf12 fork: no GitHub API lookup
                } else {
                    versionDisplay = sourceInfo.version;
                }
                
                // Always load live injector.js for plan apply + stamp sync (baked preload may be stale)
                let hasPreload = false;
                try {
                    const pluginId = await findJavaScriptInjectorPlugin();
                    const injCfg = await getJavaScriptInjectorConfig(pluginId);
                    hasPreload = (injCfg.CustomJavaScripts || []).some(
                        (s) => s.Name === 'KefinTweaks-injector' && s.Enabled !== false
                    );
                } catch (e) {
                    console.warn('[KefinTweaks Installer] Could not verify KefinTweaks-injector after save:', e);
                }
                if (hasPreload) {
                    console.log('[KefinTweaks Installer] KefinTweaks-injector saved; still loading injector.js for live plan + sync');
                }
                if (!BOOTSTRAPPED) await loadInjectorFromRoot(kefinTweaksRoot);          // bootstrapped: injector.js is running from the old location already, a second one would double everything - the page is reloaded instead
                
                // Show success modal
                await showSuccessModal(isInitialInstall, versionDisplay);
            } catch (error) {
                console.error('[KefinTweaks Installer] Error saving configuration:', error);
                showAlertModal('配置错误', `<p>保存配置时出错：${error.message}</p>`);
            }
        };
        
        const uninstallBtn = document.createElement('button');
        uninstallBtn.className = 'btnCancel raised emby-button button-cancel';
        uninstallBtn.textContent = '卸载';
        uninstallBtn.style.marginRight = 'auto';
        // Hide uninstall button if KefinTweaks isn't installed yet (no root URL)
        if (!currentRoot || currentRoot.trim() === '') {
            uninstallBtn.style.display = 'none';
        }
        uninstallBtn.onclick = () => {
            closeSimpleModal(MODAL_ID);
            showConfirmationModal(
                '确定要卸载 KefinTweaks 吗？<br><br>这将禁用安装器并备份您的配置。',
                async () => {
                    try {
                        await uninstallKefinTweaks();
                        // Remove the plugin card
                        removeKefinTweaksPluginCard();
                        showAlertModal(
                            'KefinTweaks 已卸载',
                            '<p>KefinTweaks 已卸载。安装器已被禁用，您的配置已备份。<br><br>请刷新页面。<br><br>您可以随时在 JS Injector 插件中重新启用 KefinTweaks。'
                        );
                    } catch (error) {
                        console.error('[KefinTweaks Installer] Error uninstalling:', error);
                        showAlertModal(
                            '卸载出错',
                            `<p>卸载 KefinTweaks 时出错：${error.message}</p>`
                        );
                    }
                },
                () => {
                    // User cancelled, reopen the source modal
                    openKefinTweaksSourceModal();
                }
            );
        };

        footer.appendChild(saveBtn);
        footer.appendChild(cancelBtn);
        footer.appendChild(uninstallBtn);

        createSimpleModal(MODAL_ID, 'KefinTweaks 插件设置', content, footer);
    }

    /**
     * Uninstall KefinTweaks
     * 1. Renames KefinTweaks-Config to KefinTweaks-Config-Backup-Timestamp
     * 2. Disables the installer script (script containing kefinTweaks-plugin.js)
     */
    async function uninstallKefinTweaks() {
        try {
            const pluginId = await findJavaScriptInjectorPlugin();
            const injectorConfig = await getJavaScriptInjectorConfig(pluginId);
            
            if (!injectorConfig.CustomJavaScripts) {
                throw new Error('JS Injector 配置中未找到自定义脚本');
            }

            // Step 1: Rename KefinTweaks-Config to backup
            const configScriptIndex = injectorConfig.CustomJavaScripts.findIndex(
                script => script.Name === 'KefinTweaks-Config'
            );
            
            if (configScriptIndex !== -1) {
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
                injectorConfig.CustomJavaScripts[configScriptIndex].Name = `KefinTweaks-Config-Backup-${timestamp}`;
                injectorConfig.CustomJavaScripts[configScriptIndex].Enabled = false;
                console.log('[KefinTweaks Installer] Renamed KefinTweaks-Config to backup and disabled it');
            }

            // Also disable/rename KefinTweaks-injector preload entry
            const injectorScriptIndex = injectorConfig.CustomJavaScripts.findIndex(
                script => script.Name === 'KefinTweaks-injector'
            );
            if (injectorScriptIndex !== -1) {
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
                injectorConfig.CustomJavaScripts[injectorScriptIndex].Name = `KefinTweaks-injector-Backup-${timestamp}`;
                injectorConfig.CustomJavaScripts[injectorScriptIndex].Enabled = false;
                console.log('[KefinTweaks Installer] Renamed KefinTweaks-injector to backup and disabled it');
            }

            // Step 2: Find and disable installer script
            // Look for script containing kefinTweaks-plugin.js (flexible pattern to match script.src*kefinTweaks-plugin.js)
            const installerScriptIndex = injectorConfig.CustomJavaScripts.findIndex(
                script => script.Script && /script\.src.*kefinTweaks-plugin\.js/i.test(script.Script)
            );
            
            if (installerScriptIndex !== -1) {
                injectorConfig.CustomJavaScripts[installerScriptIndex].Enabled = false;
                console.log('[KefinTweaks Installer] Disabled installer script');
            } else {
                console.warn('[KefinTweaks Installer] Installer script not found in CustomJavaScripts');
            }

            // Save the updated configuration
            const server = ApiClient._serverAddress;

            const response = await fetch(`${server}/Plugins/${pluginId}/Configuration`, {
                method: 'POST',
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(injectorConfig)
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            console.log('[KefinTweaks Installer] Uninstall completed successfully');
            return true;
        } catch (error) {
            console.error('[KefinTweaks Installer] Error uninstalling:', error);
            throw error;
        }
    }

    /**
     * Update the plugin card with new version and status information
     */
    async function updateKefinTweaksPluginCard() {
        const card = document.querySelector('[data-id="kefinTweaksPlugin"]');
        if (!card) {
            // Card doesn't exist yet, try to add it
            const pluginsPage = document.querySelector('#pluginsPage:not(.hide)');
            if (pluginsPage) {
                let installedPlugins = pluginsPage.querySelector('.installedPlugins');
                if (!installedPlugins) {
                    installedPlugins = document.querySelector('#pluginsPage:not(.hide)>div>div>div:last-child>div');
                }
                if (installedPlugins) {
                    addKefinTweaksPluginCard(installedPlugins);
                }
            }
            return;
        }

        try {
            const config = await getKefinTweaksConfig();
            const root = config?.kefinTweaksRoot || '';
            const sourceInfo = parseKefinTweaksSource(root);
            
            // Determine version display text
            let versionDisplay = 'Installation Pending';
            if (root) {
                if (sourceInfo.sourceType === 'custom') {
                    versionDisplay = SELF_HOSTED_NAME;
                } else if (sourceInfo.version === DEVELOPMENT_NAME) {
                    versionDisplay = DEVELOPMENT_NAME;
                } else if (sourceInfo.version === LATEST_RELEASE_NAME) {
                    versionDisplay = LATEST_RELEASE_NAME; // jf12 fork: no GitHub API lookup
                } else {
                    // Specific version
                    versionDisplay = sourceInfo.version;
                }
            }

            // Update data attributes
            card.setAttribute('data-version', versionDisplay);
            card.setAttribute('data-status', root ? 'Active' : 'Pending');

            // Check if this is a Material-UI card
            const isMuiCard = card.classList.contains('MuiGrid-root');
            
            if (isMuiCard) {
                // Handle Material-UI card structure
                const versionElement = card.querySelector('.MuiTypography-root.MuiTypography-body2');
                if (versionElement) {
                    versionElement.textContent = versionDisplay;
                }
            } else {
                // Handle standard card structure
                const cardTextElements = card.querySelectorAll('.cardText');
                if (cardTextElements.length > 0) {
                    // Update first cardText (plugin name with version)
                    const nameElement = cardTextElements[0];
                    const versionSpan = nameElement.querySelector('.cardText-secondary');
                    if (versionSpan) {
                        versionSpan.textContent = versionDisplay;
                    } else {
                        // If no secondary span exists, create one
                        nameElement.innerHTML = `KefinTweaks<span class="cardText cardText-secondary">${versionDisplay}</span>`;
                    }
                }

                // Determine status text
                const statusText = root ? '状态：激活' : '点击安装';

                // Update status text (usually last cardText)
                if (cardTextElements.length > 0) {
                    cardTextElements[cardTextElements.length - 1].textContent = statusText;
                }
            }
        } catch (error) {
            console.error('[KefinTweaks Installer] Error updating plugin card:', error);
        }
    }

    /**
     * Remove the plugin card from the DOM
     */
    function removeKefinTweaksPluginCard() {
        const card = document.querySelector('[data-id="kefinTweaksPlugin"]');
        if (card) {
            card.remove();
            console.log('[KefinTweaks Installer] Plugin card removed');
        }
    }

    // Make function globally accessible
    window.openKefinTweaksSourceModal = openKefinTweaksSourceModal;

    // Prevent concurrent card inserts (async config fetch races past DOM checks)
    let pluginCardAddInProgress = false;
    let pluginCardObserver = null;
    let tryRenderToken = 0;

    function ensureSingleKefinTweaksPluginCard() {
        const cards = document.querySelectorAll('[data-id="kefinTweaksPlugin"]');
        for (let i = 1; i < cards.length; i++) {
            cards[i].remove();
        }
        return cards[0] || null;
    }

    // Add plugin card to plugins page
    function addKefinTweaksPluginCard(installedPlugins) {
        if (!installedPlugins) {
            return;
        }

        if (ensureSingleKefinTweaksPluginCard()) {
            return;
        }

        if (pluginCardAddInProgress) {
            return;
        }
        pluginCardAddInProgress = true;

        const pluginsPage = document.querySelector('#pluginsPage:not(.hide)');
        if (!pluginsPage) {
            pluginCardAddInProgress = false;
            return;
        }

        // Find or create frontEndPlugins container (only one)
        let frontEndPlugins = pluginsPage.querySelector('.frontEndPlugins');
        
        if (!frontEndPlugins) {
            // Create the heading
            const heading = document.createElement('div');
            heading.className = 'sectionTitleContainer flex align-items-center';
            heading.innerHTML = '<h2 class="sectionTitle">前端插件</h2>';
            heading.style.marginTop = '2em';
            
            // Create the frontEndPlugins container
            frontEndPlugins = document.createElement('div');
            frontEndPlugins.className = 'frontEndPlugins itemsContainer vertical-wrap';
            
            // Insert heading and container after installedPlugins
            if (installedPlugins.nextSibling) {
                installedPlugins.parentNode.insertBefore(heading, installedPlugins.nextSibling);
                installedPlugins.parentNode.insertBefore(frontEndPlugins, heading.nextSibling);
            } else {
                installedPlugins.parentNode.appendChild(heading);
                installedPlugins.parentNode.appendChild(frontEndPlugins);
            }
        }

        // Find an existing plugin card to clone
        // Try multiple selectors to find a plugin card
        const existingCard = installedPlugins.querySelector('.card[data-id]') || 
                             installedPlugins.querySelector(':first-child') ||
                             installedPlugins.firstElementChild;
        
        if (!existingCard) {
            if (pluginCardObserver) {
                // Already waiting for native plugin cards; keep in-progress lock
                return;
            }

            console.log('[KefinTweaks Installer] No existing plugin card found, setting up MutationObserver');
            
            pluginCardObserver = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    if (mutation.addedNodes.length > 0) {
                        const cardToClone = installedPlugins.querySelector('.card[data-id]') || 
                                          installedPlugins.querySelector(':first-child') ||
                                          installedPlugins.firstElementChild;
                        
                        if (cardToClone) {
                            console.log('[KefinTweaks Installer] Plugin card detected, disconnecting observer');
                            pluginCardObserver.disconnect();
                            pluginCardObserver = null;
                            pluginCardAddInProgress = false;
                            addKefinTweaksPluginCard(installedPlugins);
                            return;
                        }
                    }
                }
            });
            
            pluginCardObserver.observe(installedPlugins, {
                childList: true,
                subtree: false
            });
            
            setTimeout(() => {
                if (pluginCardObserver) {
                    pluginCardObserver.disconnect();
                    pluginCardObserver = null;
                    pluginCardAddInProgress = false;
                    console.warn('[KefinTweaks Installer] MutationObserver timeout: No plugin cards appeared after 10 seconds');
                }
            }, 10000);
            
            return;
        }

        // Get current config to determine version/status
        getKefinTweaksConfig().then(async config => {
            const root = config?.kefinTweaksRoot || '';
            const sourceInfo = parseKefinTweaksSource(root);
            
            // Determine version display text
            let versionDisplay = 'Installation Pending';
            if (root) {
                if (sourceInfo.sourceType === 'custom') {
                    versionDisplay = SELF_HOSTED_NAME;
                } else if (sourceInfo.version === DEVELOPMENT_NAME) {
                    versionDisplay = DEVELOPMENT_NAME;
                } else if (sourceInfo.version === LATEST_RELEASE_NAME) {
                    versionDisplay = LATEST_RELEASE_NAME; // jf12 fork: no GitHub API lookup
                } else {
                    // Specific version
                    versionDisplay = sourceInfo.version;
                }
            }

            // Clone the existing card
            const card = existingCard.cloneNode(true);
            
            // Update data attributes
            card.setAttribute('data-id', 'kefinTweaksPlugin');
            card.setAttribute('data-version', versionDisplay);
            card.setAttribute('data-name', 'KefinTweaks');
            card.setAttribute('data-removable', 'true');
            card.setAttribute('data-status', root ? 'Active' : 'Pending');

            // Check if this is a Material-UI card (MuiGrid-root)
            const isMuiCard = card.classList.contains('MuiGrid-root');
            
            if (isMuiCard) {
                // Handle Material-UI card structure
                const nameElement = card.querySelector('.MuiTypography-root.MuiTypography-body1');
                const versionElement = card.querySelector('.MuiTypography-root.MuiTypography-body2');
                
                if (nameElement) {
                    nameElement.textContent = 'KefinTweaks';
                }
                
                if (versionElement) {
                    versionElement.textContent = versionDisplay;
                }
            } else {
                // Handle standard card structure
                const cardTextElements = card.querySelectorAll('.cardText');
                if (cardTextElements.length > 0) {
                    // Update first cardText (plugin name with version)
                    const nameElement = cardTextElements[0];
                    const versionSpan = nameElement.querySelector('.cardText-secondary');
                    if (versionSpan) {
                        // Update existing version span
                        versionSpan.textContent = versionDisplay;
                        // Update the name part (text before the span)
                        if (nameElement.firstChild && nameElement.firstChild.nodeType === Node.TEXT_NODE) {
                            nameElement.firstChild.textContent = 'KefinTweaks';
                        } else {
                            // Insert name text before the version span
                            nameElement.insertBefore(document.createTextNode('KefinTweaks'), versionSpan);
                        }
                    } else {
                        // If no secondary span exists, create one
                        nameElement.innerHTML = `KefinTweaks<span class="cardText cardText-secondary">${versionDisplay}</span>`;
                    }
                }
            
                // Determine status text
                const statusText = root ? '状态：激活' : '点击安装';

                // Update status text (usually last cardText)
                if (cardTextElements.length > 0) {
                    cardTextElements[cardTextElements.length - 1].textContent = statusText;
                } else {
                    // Add status if it doesn't exist
                    const cardFooter = card.querySelector('.cardFooter');
                    if (cardFooter) {
                        const statusElement = document.createElement('div');
                        statusElement.className = 'cardText';
                        statusElement.textContent = statusText;
                        cardFooter.appendChild(statusElement);
                    }
                }
            }

            // Find and replace the anchor/link with a button that opens the modal
            // For Material-UI cards, the anchor might be structured differently
            let anchorElement = null;
            
            if (isMuiCard) {
                // For Material-UI cards, look for anchor in various possible locations
                anchorElement = card.querySelector('a[href]') || 
                               card.querySelector('.MuiCardActionArea') ||
                               card.querySelector('a');
            } else {
                // For standard cards, look for .cardImageContainer
                anchorElement = card.querySelector('.cardImageContainer');
            }
            
            if (anchorElement) {
                // Remove existing link attributes
                anchorElement.removeAttribute('href');
                anchorElement.removeAttribute('data-url');
                anchorElement.removeAttribute('target');
                
                // Convert to button if it's not already
                if (anchorElement.tagName.toLowerCase() !== 'button') {
                    const button = document.createElement('button');
                    // Copy all attributes (except link-specific ones)
                    Array.from(anchorElement.attributes).forEach(attr => {
                        if (attr.name !== 'href' && attr.name !== 'data-url' && attr.name !== 'target') {
                            button.setAttribute(attr.name, attr.value);
                        }
                    });
                    button.className = anchorElement.className;
                    
                    // For Material-UI, preserve Mui classes but add button behavior
                    if (isMuiCard) {
                        button.setAttribute('type', 'button');
                        // Preserve MuiCardActionArea if it exists
                        if (anchorElement.classList.contains('MuiCardActionArea')) {
                            button.classList.add('MuiCardActionArea');
                        }
                    } else {
                        button.setAttribute('is', 'emby-linkbutton');
                        button.style.margin = '0';
                        button.style.padding = '0';
                    }
                    
                    // Copy all child nodes
                    while (anchorElement.firstChild) {
                        button.appendChild(anchorElement.firstChild);
                    }
                    
                    // Replace the element
                    anchorElement.parentNode.replaceChild(button, anchorElement);
                    button.onclick = (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        openKefinTweaksSourceModal();
                    };
                } else {
                    // It's already a button, just update onclick
                    anchorElement.onclick = (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        openKefinTweaksSourceModal();
                    };
                }

                // Replace any existing img tag with icon div
                let img = card.querySelector('img');
    
                if (img) {
                    img.src = (window.KefinTweaksConfig?.kefinTweaksRoot || '').replace(/\/?$/, '/') + 'logo.png';
                    img.style.width = 'auto';
                    img.style.height = '100%';
                    img.parentNode.style.background = 'linear-gradient(to bottom, #202020, #101010)';
                } else {
                    img = document.createElement('div');
                    img.className = 'defaultCardBackground';
                    // give the gradient some color
                    img.style.background = 'url(' + (window.KefinTweaksConfig?.kefinTweaksRoot || '').replace(/\/?$/, '/') + 'logo.png), linear-gradient(to bottom, #202020, #101010)';
                    img.style.backgroundSize = 'contain';
                    img.style.backgroundPosition = 'center';
                    img.style.backgroundRepeat = 'no-repeat';
                    img.style.width = '100%';
                    img.style.height = '100%';
                    img.style.overflow = 'hidden';
                    img.style.display = 'flex';
                }

                let defaultCardBackground = card.querySelector('.defaultCardBackground') ?? card.querySelector('.MuiCardMedia-root');
                
                if (img && defaultCardBackground) {
                    // Replace the defaultCardBackground with the img
                    defaultCardBackground.parentNode.replaceChild(img, defaultCardBackground);
                }
            }

            // Find and handle menu button (btnCardMenu) if it exists
            const menuButton = card.querySelector('.btnCardMenu');
            if (menuButton) {
                // Remove existing click handlers by cloning
                const clonedMenuButton = menuButton.cloneNode(true);
                menuButton.parentNode.replaceChild(clonedMenuButton, menuButton);
                
                // Add click handler to open modal
                clonedMenuButton.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    openKefinTweaksSourceModal();
                };
            }

            // Append only if still missing (guards against concurrent async completions)
            if (ensureSingleKefinTweaksPluginCard()) {
                return;
            }
            frontEndPlugins.appendChild(card);
        }).catch(err => {
            console.error('[KefinTweaks Installer] Error getting config for card:', err);
        }).finally(() => {
            pluginCardAddInProgress = false;
        });
    }

    // Try to render the Front End Plugins card when on the plugins page
    async function tryRenderPluginsPage(retryCount = 0) {
        const maxRetries = 50; // ~5s (50 * 100ms)
        if (retryCount === 0) {
            tryRenderToken += 1;
        }
        const token = tryRenderToken;

        const hash = window.location.hash || '';

        if (!hash.includes('dashboard/plugins')) {
            return;
        }

        const pluginsPage = document.querySelector('#pluginsPage:not(.hide)');
        let installedPlugins = pluginsPage ? pluginsPage.querySelector('.installedPlugins') : null;

        if (!installedPlugins && pluginsPage) {
            // Support for Jellyfin 10.11.X
            installedPlugins = document.querySelector('#pluginsPage:not(.hide)>div>div>div:last-child>div');
        }

        if (!pluginsPage || !installedPlugins) {
            if (retryCount < maxRetries) {
                setTimeout(() => {
                    if (token !== tryRenderToken) {
                        return;
                    }
                    tryRenderPluginsPage(retryCount + 1);
                }, 100);
            }
            return;
        }

        ensureSingleKefinTweaksPluginCard();

        if (!(await isAdmin())) {
            return;
        }

        if (token !== tryRenderToken) {
            return;
        }

        addKefinTweaksPluginCard(installedPlugins);
    }

    // Hook into Emby.Page.onViewShow
    function setupOnViewShow() {
        if (!(window.Emby && window.Emby.Page)) {
            setTimeout(setupOnViewShow, 100);
            return;
        }

        if (window.Emby.Page._kefinTweaksOnViewShowHooked) {
            return;
        }
        window.Emby.Page._kefinTweaksOnViewShowHooked = true;

        const originalOnViewShow = window.Emby.Page.onViewShow;

        window.Emby.Page.onViewShow = function(...args) {
            if (originalOnViewShow) {
                try {
                    originalOnViewShow.apply(this, args);
                } catch (err) {
                    console.warn('[KefinTweaks Installer] Error in original onViewShow:', err);
                }
            }

            tryRenderPluginsPage();
        };

        console.log('[KefinTweaks Installer] Hooked into Emby.Page.onViewShow');

        // Cover direct URL / reload when onViewShow already fired before the hook
        tryRenderPluginsPage();
    }

    function injectPluginCardCss() {
        if (document.getElementById('kefinTweaksPluginCardCss')) {
            return;
        }
        const css = document.createElement('style');
        css.id = 'kefinTweaksPluginCardCss';
        css.textContent = `
            [data-id="kefinTweaksPlugin"] .cardImageContainer::after,
            [data-id="kefinTweaksPlugin"] .MuiButtonBase-root.MuiCardActionArea-root::after {
                content: 'KefinTweaks';
                position: absolute;
                font-size: 2em;
                top: 50%;
                transform: translateY(-50%);
            }
        `;
        document.head.appendChild(css);
    }

    function shouldInjectCustomPageStyles(config) {
        if (!config) return false;
        const scripts = config.scripts || {};
        const links = config.customMenuLinks;
        return scripts.watchlist === true
            || scripts.games === true
            || (Array.isArray(links) && links.length > 0);
    }

    // jf12 fork (#123): the same stylesheet as scripts/utils.js (CUSTOM_PAGE_STYLES_CSS, same style id). Every rule that hides Jellyfin
    // content is scoped to html.kefin-custom-page-route, set only while the URL is a KefinTweaks route (#/watchlist, #/games), so a real
    // "Page not found" and the page titles of every other page are left alone.
    function injectCustomPageStyles(config) {
        if (!shouldInjectCustomPageStyles(config)) return;

        const css = `
html.kefin-custom-page-route #reactRoot.kefin-custom-page-active .skinBody #fallbackPage {
	display: none;
}

html.kefin-custom-page-route #reactRoot:not(.kefin-custom-page-active) .pageTitle {
	visibility: hidden;
}

html.kefin-custom-page-route #reactRoot:not(.kefin-custom-page-active):not([data-kefin-fallback-ready]) .skinBody #fallbackPage > * {
	display: none;
}

html.kefin-custom-page-route #reactRoot:not(.kefin-custom-page-active):not([data-kefin-fallback-ready]) #fallbackPage::after {
	content: '';
	display: inline-block;
	width: 20px;
	height: 20px;
	border: 3px solid #f3f3f3;
	border-top: 3px solid #4ecdc4;
	border-radius: 50%;
	animation: spin 1s linear infinite;
	position: relative;
	left: 50%;
	transform: translateX(-50%);
	top: 1em;
}

html.kefin-custom-page-route #reactRoot.kefin-custom-page-active .backdropImage {
	background: none !important;
}

header.MuiPaper-root + main.MuiBox-root .customPage {
	margin-top: 3rem;
}

.layout-mobile .kefin-custom-page-active .MuiToolbar-root > .MuiStack-root > :nth-child(n+2),
.layout-mobile .kefin-custom-page-active .MuiToolbar-root > .MuiStack-root > :first-child .MuiButton-icon img {
  display: none;
}
.layout-mobile .kefin-custom-page-active .MuiToolbar-root > .MuiStack-root > :first-child .MuiButton-icon::after {
  content: '\\e88a';
  font-family: 'Material Icons';
  font-size: 1.2rem;
}
.layout-mobile .kefin-custom-page-active .MuiToolbar-root > .MuiStack-root > :first-child {
  font-size: 0px;
}
main.MuiBox-root .customPage.libraryPage:not(.noSecondaryNavPage)[data-kefin-custom-page] {
  padding-top:  1rem !important;
}
.layout-mobile :not(main.MuiBox-root) > .skinBody > .customPage.libraryPage:not(.noSecondaryNavPage)[data-kefin-custom-page] {
  padding-top:  5rem !important;
}
`;
        let style = document.getElementById('kefin-custom-page-styles');
        if (!style) {
            style = document.createElement('style');
            style.id = 'kefin-custom-page-styles';
            (document.head || document.documentElement).appendChild(style);
        }
        style.textContent = css;

        // mark a KefinTweaks route that is open right now (utils.js keeps the class in sync afterwards)
        const scripts = (config && config.scripts) || {};
        const path = String(window.location.hash || '').split('?')[0].replace(/\/$/, '');
        const routes = [];
        if (scripts.watchlist !== false) routes.push('#/watchlist');
        if (scripts.games === true) routes.push('#/games');
        document.documentElement.classList.toggle('kefin-custom-page-route', routes.includes(path));
    }

    // Initialize the installer (no login/admin gate — admin is checked when rendering the card)
    function initialize() {
        checkAndLoadInjector();
        if (BOOTSTRAPPED) return;          // dialog only: no card on the Plugins page
        injectPluginCardCss();
        setupOnViewShow();
    }

    // jf12 fork: roots are used as configured; nothing is resolved through the GitHub API
    async function resolveRootVersion(root) {
        return root;
    }

    // jf12 fork: does this location serve KefinTweaks? The default config sits next to injector.js and defines a global, and a script tag needs no CORS (the files are loaded the same way).
    function probeKefinRoot(root) {
        const url = (root.endsWith('/') ? root : root + '/') + 'kefinTweaks-default-config.js';
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            const fail = (why) => { script.remove(); reject(new Error(`${url} ${why}。这是存放 injector.js 的目录吗？`)); };
            const timer = setTimeout(() => fail('在 10 秒内未响应'), 10000);
            script.onload = () => { clearTimeout(timer); script.remove(); window.KefinTweaksDefaultConfig ? resolve() : fail('已加载，但不是 KefinTweaks 的默认配置'); };
            script.onerror = () => { clearTimeout(timer); fail('无法加载'); };
            script.src = url + '?probe=' + Date.now();
            document.head.appendChild(script);
        });
    }

    // Load injector.js from a specific root URL (resolves floating refs first)
    async function loadInjectorFromRoot(root) {
        if (!root || root === '') {
            console.warn('[KefinTweaks Installer] Cannot load injector: kefinTweaksRoot is empty');
            return false;
        }

        // Ensure root ends with /
        const rootUrl = root.endsWith('/') ? root : root + '/';
        const resolvedRoot = await resolveRootVersion(rootUrl);
        const injectorUrl = `${resolvedRoot}injector.js`;

        if (resolvedRoot !== rootUrl) {
            console.log('[KefinTweaks Installer] Resolved root from', rootUrl, 'to', resolvedRoot);
        }

        // Check if injector is already loaded from this URL
        const existingScript = document.querySelector(`script[src="${injectorUrl}"]`);
        if (existingScript) {
            console.log('[KefinTweaks Installer] Injector already loaded from:', injectorUrl);
            return true;
        }

        console.log('[KefinTweaks Installer] Loading injector.js from:', injectorUrl);

        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = injectorUrl;
            script.async = true;

            script.onload = () => {
                console.log('[KefinTweaks Installer] Injector loaded successfully');
                resolve(true);
            };

            script.onerror = (error) => {
                console.error('[KefinTweaks Installer] Failed to load injector:', error);
                reject(new Error(`无法从 ${injectorUrl} 加载 injector.js`));
            };

            document.head.appendChild(script);
        });
    }

    // Check if config exists; auto-create KefinTweaks-injector when missing; always load live injector.js
    async function checkAndLoadInjector() {
        try {
            const config = await getKefinTweaksConfig();
            const root = config?.kefinTweaksRoot || '';

            // Before injector/utils: hide fallback page chrome for custom routes
            injectCustomPageStyles(config);

            if (!root || root === '') {
                console.log('[KefinTweaks Installer] kefinTweaksRoot not configured. Please configure via the Plugins page.');
                return;
            }

            // jf12 fork: read-only. Upstream created / rewrote the KefinTweaks-injector entry in the JS Injector plugin from
            // this page load when it was missing; here page loads never write to the server (write the entries by hand).
            if (window.KefinTweaksBootstrapRoot) {
                console.log('[KefinTweaks Installer] KefinTweaks-injector entry already loaded KefinTweaks from', window.KefinTweaksBootstrapRoot);
                return;
            }

            await loadInjectorFromRoot(root);
        } catch (error) {
            console.error('[KefinTweaks Installer] Error checking config:', error);
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            initialize();
        });
    } else {
        initialize();
    }

    console.log('[KefinTweaks Installer] Installer script loaded');
})();

